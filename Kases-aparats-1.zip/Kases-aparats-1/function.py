    if AtlaideKlik == 'True' :
      KopaCeks = (int(PirkumiCeks) + int(ZalesCeks) - int(AtlaideCeks))
    else:
      KopaCeks = (int(PirkumiCeks) + int(ZalesCeks)


      